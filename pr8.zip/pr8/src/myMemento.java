import java.util.Date;

class Doc {
    private String text;
    private Date date;

    public void setText(String text) {
        this.text = text;
        this.date = new Date();
    }

    public Memento memento(){
        return new Memento(text);
    }

    public void load(Memento memento){
        text = memento.getText();
        date = memento.getDate();
    }

    @Override
    public String toString() {
        return "Содержимое документа: \n" +
                text + "\n" +
                "Дата изменения: " + date;
    }
}

class History{
    private Memento memento;

    public Memento getMemento() {
        return memento;
    }

    public void setMemento(Memento memento) {
        this.memento = memento;
    }
}

class Memento{
    private final String text;
    private final Date date;

    public Memento(String text){
        this.text = text;
        this.date = new Date();
    }

    public String getText() {
        return text;
    }

    public Date getDate(){
        return date;
    }
}

public class myMemento {
    public static void main(String[] args) throws InterruptedException {
        Doc doc = new Doc();
        History history = new History();

        System.out.println("Создали текстовый документ \n");
        doc.setText("Привет, gradle уничтожил мою нервную систему :(");

        System.out.println(doc + "\n");

        System.out.println("Сохранили текущий документ");
        history.setMemento(doc.memento());

        System.out.println("Меняем текст в 'файле' \n");
        Thread.sleep(5000);

        doc.setText("Казалось бы, причем здесь docker");

        System.out.println(doc + "\n");

        System.out.println("Не хочу вспоминать про docker \n");

        doc.load(history.getMemento());

        System.out.println(doc);

    }
}