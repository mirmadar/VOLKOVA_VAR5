package com.example.pr15;

import com.example.pr15.models.GameAuthor;
import com.example.pr15.repositories.GameAuthorRepository;
import com.example.pr15.services.GameAuthorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class GameAuthorServiceTest {

    private GameAuthorService gameAuthorService;

    @Mock
    private GameAuthorRepository gameAuthorRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        gameAuthorService = new GameAuthorService(gameAuthorRepository);
    }

    @Test
    void testGetAllAuthors() {
        List<GameAuthor> authors = new ArrayList<>();
        authors.add(new GameAuthor(1L, "Author 1"));
        authors.add(new GameAuthor(2L, "Author 2"));
        when(gameAuthorRepository.findAll()).thenReturn(authors);
        List<GameAuthor> result = gameAuthorService.getAllAuthors();
        assertEquals(authors, result);
        verify(gameAuthorRepository, times(1)).findAll();
    }

    @Test
    void testGetAuthorById() {
        GameAuthor author = new GameAuthor(1L, "Author 1");
        when(gameAuthorRepository.findById(1L)).thenReturn(Optional.of(author));
        GameAuthor result = gameAuthorService.getAuthorById(1L);
        assertEquals(author, result);
        verify(gameAuthorRepository, times(1)).findById(1L);
    }

}
