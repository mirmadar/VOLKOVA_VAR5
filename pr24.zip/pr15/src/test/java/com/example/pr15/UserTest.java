
package com.example.pr15;

import com.example.pr15.repositories.UserRepository;
import com.example.pr15.models.UserData;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserTest
{
    @Autowired
    private UserRepository userRepository;


    @Test
    public void Test1(){
        UserData user = new UserData();
        user.setId(1);
        user.setUsername("bob");
        user.setPassword("1234");

        userRepository.save(user);

        Assertions.assertEquals("1234", userRepository.findByUsername("bob").getPassword());
    }
}
