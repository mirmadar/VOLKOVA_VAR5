package com.example.pr15.services;

import com.example.pr15.logging.LogTime;
import com.example.pr15.models.Game;
import com.example.pr15.models.GameAuthor;
import com.example.pr15.repositories.GameRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
@Service
@Slf4j
@ManagedResource
//@RequiredArgsConstructor
@Configuration
@EnableScheduling
public class GameService {

    private final GameRepository gameRepository;
    private static final Logger logger = LoggerFactory.getLogger(GameService.class);

    public GameService(GameRepository gameRepository) {
        this.gameRepository = gameRepository;
    }

    @LogTime
    public Game createGame(Game game) {
        logger.debug("Creating game: {}", game);
        GameAuthor author = game.getAuthor();
        if (author.getGames() == null) {
            author.setGames(new ArrayList<>());
        }
        author.getGames().add(game); // связываем игру с автором
        Game savedGame = gameRepository.save(game);
        logger.debug("Game created: {}", savedGame);
        return savedGame;
    }

    @LogTime
    public List<Game> getAllGames() {
        logger.debug("Getting all games");
        List<Game> games = gameRepository.findAll();
        logger.debug("Found {} games", games.size());
        return games;
    }
    @LogTime
    public void deleteGameById(Long id) {
        logger.debug("Deleting game with id: {}", id);
        gameRepository.deleteById(id);
        logger.debug("Game with id {} deleted", id);
    }

    @PersistenceContext
    private EntityManager entityManager;

    @LogTime
    public List<Game> filterGames(String name, Long authorId, String creationDate) {
        logger.debug("Filtering games with name: {}, authorId: {}, creationDate: {}", name, authorId, creationDate);
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Game> criteriaQuery = builder.createQuery(Game.class);
        Root<Game> root = criteriaQuery.from(Game.class);
        List<Predicate> predicates = new ArrayList<>();
        if (name != null) {
            predicates.add(builder.like(root.get("name"), "%" + name + "%"));
        }
        if (authorId != null) {
            Join<Game, GameAuthor> authorJoin = root.join("author");
            predicates.add(builder.equal(authorJoin.get("id"), authorId));
        }
        if (creationDate != null) {
            predicates.add(builder.equal(root.get("creationDate"), creationDate));
        }
        criteriaQuery.where(predicates.toArray(new Predicate[predicates.size()]));
        TypedQuery<Game> query = entityManager.createQuery(criteriaQuery);
        List<Game> games = query.getResultList();
        logger.debug("Found {} games", games.size());
        return games;
    }
    private final String filesDir = "src/main/resources/22/";
    public boolean clearDirectory() {
        Path dir = Paths.get(filesDir);
        log.info("Path find: {}", dir);
        try {
            Files.list(dir).forEach(x -> {
                File file = new File(String.valueOf(x.toFile()));
                log.info("Delete file repository: {}", file.getAbsolutePath());
                file.delete();
            });
        } catch (IOException e) {
            return true;
        }
        return true;
    }

    @ManagedOperation(description = "Clear backup directory, create .txt files with data from DB")
    @Scheduled(fixedDelay = 10000)  //every minute
    public void backupFromDataBase() {
        if (clearDirectory()) {
            try {
                log.info("Started writing data from DB");
                FileWriter fileWriter = new FileWriter(filesDir + "games.txt", true);
                gameRepository.findAll().forEach(patientInfo -> {
                    try {
                        fileWriter.write(patientInfo.toString());
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
                fileWriter.close();
                log.info("Finished writing data from DB");
            } catch (IOException exception) {
                exception.printStackTrace();
                log.info("Something went wrong...");
            }
        }
    }
}