package com.example.pr15.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "games")
public class Game {
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "creation_date")
    private String creationDate;

    @JsonIgnore
    @ManyToOne()
    @JoinColumn(name = "id_author", referencedColumnName = "id")
    private GameAuthor author;

    public Game(Long id, GameAuthor author, String name, String creationDate) {
        this.id = id;
        this.author = author;
        this.name = name;
        this.creationDate = creationDate;
    }

    public Game() {}

    @Override
    public String toString() {
        return "Game: {" +
                "id: " + id +
                ", name: '" + name + '\'' +
                ", author: " + author +
                ", creationDate: " + creationDate +
                '}';
    }
}
