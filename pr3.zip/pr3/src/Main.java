import java.util.*;
import java.util.concurrent.Semaphore;

public class Main {
    public static void main(String[] args) {
        Set<Student> studentSet = new TreeSet<>(Comparator.comparingInt(Student::getNumber));
        studentSet.add(new Student(2,"Спанчбоб"));
        studentSet.add(new Student(5,"Патрик"));
        studentSet.add(new Student(1,"Сэнди"));
        studentSet.add(new Student(4,"Мистер Крабс"));
        studentSet.add(new Student(3,"Сквидвард"));

        Semaphore queue = new Semaphore(2);

        for (Student student : studentSet) {
            student.setSemaphore(queue);
            student.start();
        }

    }
}

class Student extends Thread {
    public int number;
    public String studentName;
    private Semaphore semaphore;

    public void run(){
        try {
            semaphore.acquire();
            System.out.println(studentName + " пошел отвечать билет");
            Thread.sleep(1000);
            System.out.println(studentName + " сдал экзамен");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            semaphore.release();
        }
    }

    public Student(int number, String name) {
        this.number = number;
        this.studentName = name;
    }



     public int getNumber() {
        return number;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setSemaphore(Semaphore semaphore) {
        this.semaphore = semaphore;
    }
}
