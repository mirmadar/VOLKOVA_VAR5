/*
1. Классический Singleton
Этот подход использует статическую переменную и метод getInstance (), который создает экземпляр класса при
первом вызове и возвращает тот же экземпляр во всех последующих вызовах.
Недостатком этого подхода является потенциальная проблема с многопоточностью, когда два потока могут одновременно
создавать экземпляр класса.
 */
public class Singleton {
    private static Singleton instance;
    public static synchronized Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }
}