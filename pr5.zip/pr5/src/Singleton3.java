/*
3. Singleton с использованием статического блока
Этот подход использует статический блок для создания экземпляра класса.
Это обеспечивает ленивую инициализацию Singleton и также обеспечивает безопасность многопоточности.
Однако, если при создании экземпляра класса происходит исключение, то это может привести к проблемам с загрузкой класса.
 */
public class Singleton3 {
    private static Singleton3 instance;

    private Singleton3() {}

    static { //Статический блок, который выполняется при первой загрузке класса синглтон3
        try {
            instance = new Singleton3();
        } catch (Exception e) {
            throw new RuntimeException("Error creating singleton instance");
        }
    }

    public static Singleton3 getInstance() {
        return instance;
    }
}

