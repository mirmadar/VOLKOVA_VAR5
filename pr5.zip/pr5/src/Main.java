public class Main {
    public static void main(String[] args) {
        Singleton singleton1 = Singleton.getInstance();
        Singleton singleton2 = Singleton.getInstance();
        System.out.println(singleton1 == singleton2);

        Singleton2 ob1 = Singleton2.INSTANCE;
        Singleton2 ob2 = Singleton2.INSTANCE;
        System.out.println(ob1 == ob2);

        Singleton3 cat = Singleton3.getInstance();
        Singleton3 dog = Singleton3.getInstance();
        System.out.println(cat == dog);
    }
}
