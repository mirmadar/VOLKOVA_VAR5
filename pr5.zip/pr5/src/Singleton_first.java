public class Singleton_first {
    private static Singleton_first instance; //переменная, содержащая

    private Singleton_first() {
    }

    public static Singleton_first getInstance() {
        if (instance == null) {
            instance = new Singleton_first();
        }
        return instance;
    }
}
