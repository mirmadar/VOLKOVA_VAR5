import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

interface Job {
    void apply(Applicant applicant);
}

class JobPosting implements Job {
    private String jobTitle;
    private int salary;
    private List<Applicant> applicants = new ArrayList<>();

    public JobPosting(String jobTitle, int salary) {
        this.jobTitle = jobTitle;
        this.salary = salary;
    }

    public int getSalary() {
        return salary;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void apply(Applicant applicant) {
        applicants.add(applicant);
    }

    public List<Applicant> getApplicants() {
        return applicants;
    }
}

class Applicant {
    private String name;
    private String contactInfo;
    private String experience;

    public Applicant(String name, String contactInfo, String experience) {
        this.name = name;
        this.contactInfo = contactInfo;
        this.experience = experience;
    }

    public String getName() {
        return name;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public String getExperience() {
        return "опыт работы " + experience;
    }
}

class ApplicantFactory {
    private static final Map<String, Applicant> applicants = new HashMap<>();

    public static Applicant getApplicant(String name, String contactInfo, String experience) {
        Applicant applicant = applicants.get(name);

        if (applicant == null) {
            applicant = new Applicant(name, contactInfo, experience);
            applicants.put(name, applicant);
        }

        return applicant;
    }
}

public class myFlyweight {
    public static void main(String[] args) {
        JobPosting job1 = new JobPosting("Java Разработчик", 50000);
        JobPosting job2 = new JobPosting("Python Разработчик", 45000);
        JobPosting job3 = new JobPosting("C++ Разработчик", 30000);

        Applicant applicant1 = ApplicantFactory.getApplicant("Мария", "maria@gmail.com", "3 года");
        Applicant applicant2 = ApplicantFactory.getApplicant("Олег", "oleg@gmail.com", "3 месяца");
        Applicant applicant3 = ApplicantFactory.getApplicant("Петр", "peter@mail.ru", "9 лет");
        Applicant applicant4 = ApplicantFactory.getApplicant("Евгения", "zheks@mail.ru", "2 года");
        Applicant applicant5 = ApplicantFactory.getApplicant("Олеся", "olesya@gmail.com", "9 месяцев");

        job1.apply(applicant1);
        job1.apply(applicant3);
        job2.apply(applicant2);
        job2.apply(applicant5);
        job3.apply(applicant4);

        System.out.println("Откликнувшиеся на вакансию " + job1.getJobTitle() + ":");
        for (Applicant applicant : job1.getApplicants()) {
            System.out.println(applicant.getName() + " - " + applicant.getExperience() + ", контактные данные " + applicant.getContactInfo());
        }

        System.out.println("Откликнувшиеся на вакансию " + job2.getJobTitle() + ":");
        for (Applicant applicant : job2.getApplicants()) {
            System.out.println(applicant.getName() + " - " + applicant.getExperience() + ", контактные данные " + applicant.getContactInfo());
        }

        System.out.println("Откликнувшиеся на вакансию " + job3.getJobTitle() + ":");
        for (Applicant applicant : job3.getApplicants()) {
            System.out.println(applicant.getName() + " - " + applicant.getExperience()+ ", контактные данные " + applicant.getContactInfo());
        }

        System.out.println("Зарплата должности " + '"' + job1.getJobTitle() + '"' + " - " + job1.getSalary() + " рублей");
    }
}
