/*5) Фасад, Легковес
Facade - скрывает сложную систему классов приводя все вызовы к одному объекту.
Помещает вызов нескольких сложных объектов в один объект.
 */
interface Pancake {
    void start();
    void stop();
}
class Plate implements Pancake {
    public void start() {
        System.out.println("Включить плиту");
    }
    public void stop() {
        System.out.println("Выключить плиту");
    }
}
class Pan implements Pancake{
    public void start(){
        System.out.println("Поставить сковороду на плиту");
    }
    public void stop(){
        System.out.println("Убрать сковороду с плиты");
    }
}
class Baking implements Pancake {
    public void start() {
        System.out.println("Налить тесто на сковороду");
    }
    public void stop() {
        System.out.println("Взять выпеченный блинчик");
    }
}
class Facade {
    private Plate plate;
    private Pan pan;
    private Baking baking;

    public Facade() {
        plate = new Plate();
        pan = new Pan();
        baking = new Baking();
    }
    public void startCook() {
        plate.start();
        pan.start();
        baking.start();
    }
    public void stopCook() {
        baking.stop();
        plate.stop();
        pan.stop();

    }
}

public class myFacade{
    public static void main(String[] args) {
        Facade facade = new Facade();
        facade.startCook();
        System.out.println();
        facade.stopCook();
    }
}