package com.example.pr14.controllers;

import com.example.pr14.models.GameAuthor;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GameAuthorController {
    private List<GameAuthor> gameAuthors = new ArrayList<>();

    public boolean createGameAuthor(String nickname, Date birthDate) {
        GameAuthor gameAuthor = new GameAuthor(nickname, birthDate);
        return gameAuthors.add(gameAuthor);
    }

    public boolean deleteGameAuthor(GameAuthor gameAuthor) {
        return gameAuthors.remove(gameAuthor);
    }

    public List<GameAuthor> getAllGameAuthors() {
        return gameAuthors;
    }
}
