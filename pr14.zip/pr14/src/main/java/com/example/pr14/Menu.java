package com.example.pr14;
import com.example.pr14.controllers.GameAuthorController;
import com.example.pr14.controllers.GameController;
import com.example.pr14.models.Game;
import com.example.pr14.models.GameAuthor;

import java.util.List;
import java.util.Scanner;
import java.util.Date;

public class Menu {
    private GameController gameController;
    private GameAuthorController gameAuthorController;
    private Scanner scanner;

    public Menu() {
        this.gameController = new GameController();
        this.gameAuthorController = new GameAuthorController();
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        boolean exit = false;
        while (!exit) {
            System.out.println("Menu:");
            System.out.println("1. Create game");
            System.out.println("2. Delete game");
            System.out.println("3. View the list of games");
            System.out.println("4. Create game author");
            System.out.println("5. Delete game author");
            System.out.println("6. View the list of game authors");
            System.out.println("0. Exit");

            int choice = scanner.nextInt();

            switch (choice) {
                case 0:
                    exit = true;
                    break;
                case 1:
                    System.out.println("Enter the name of the game:");
                    String gameName = scanner.next();
                    Date gameCreationDate = new Date();
                    gameController.createGame(gameName, gameCreationDate);
                    System.out.println("The game has been successfully created ^_^");
                    break;
                case 2:
                    System.out.println("Enter the name of the game you want to delete:");
                    String gameNameToDelete = scanner.next();
                    List<Game> games = gameController.getAllGames();
                    Game gameToDelete = null;
                    for (Game game : games) {
                        if (game.getName().equals(gameNameToDelete)) {
                            gameToDelete = game;
                            break;
                        }
                    }
                    if (gameToDelete != null) {
                        gameController.deleteGame(gameToDelete);
                        System.out.println("The game was successfully deleted ^_^");
                    } else {
                        System.out.println("The game was not found");
                    }
                    break;
                case 3:
                    System.out.println("List of games:");
                    List<Game> gamesList = gameController.getAllGames();
                    for (Game game : gamesList) {
                        System.out.println(game.getName() + " - " + game.getCreationDate());
                    }
                    break;
                case 4:
                    System.out.println("Enter the nickname of the author of the game:");
                    String authorNickname = scanner.next();
                    Date authorBirthDate = new Date();
                    gameAuthorController.createGameAuthor(authorNickname, authorBirthDate);
                    System.out.println("The author of the game has been successfully created ^-^");
                    break;
                case 5:
                    System.out.println("Enter the nickname of the author of the game you want to delete:");
                    String authorNicknameToDelete = scanner.next();
                    List<GameAuthor> gameAuthors = gameAuthorController.getAllGameAuthors();
                    GameAuthor authorToDelete = null;
                    for (GameAuthor author : gameAuthors) {
                        if (author.getNickname().equals(authorNicknameToDelete)) {
                            authorToDelete = author;
                            break;
                        }
                    }
                    if (authorToDelete != null) {
                        gameAuthorController.deleteGameAuthor(authorToDelete);
                        System.out.println("The author of the game has been successfully deleted");
                    } else {
                        System.out.println("The author of the game has not been found");
                    }break;
                case 6:
                    System.out.println("List of authors of the game:");
                    List<GameAuthor> authorsList = gameAuthorController.getAllGameAuthors();
                    for (GameAuthor author : authorsList) {
                        System.out.println(author.getNickname() + " - " + author.getBirthDate());
                    }
                    break;
                default:
                    System.out.println("Wrong choice T-T");
                    break;
            }
        }
    }

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.start();
    }
}