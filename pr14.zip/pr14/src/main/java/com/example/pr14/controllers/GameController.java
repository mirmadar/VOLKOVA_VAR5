package com.example.pr14.controllers;

import com.example.pr14.models.Game;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GameController {
    private List<Game> games = new ArrayList<>();

    public boolean createGame(String name, Date creationDate) {
        Game game = new Game(name, creationDate);
        return games.add(game);
    }

    public boolean deleteGame(Game game) {
        return games.remove(game);
    }

    public List<Game> getAllGames() {
        return games;
    }
}
