package com.example.pr14.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/mirmad")
    public String home1() {
        return "mirmad";

    }

    @GetMapping("/rapward")
    public String home2() {
        return "rapward";

    }
}
