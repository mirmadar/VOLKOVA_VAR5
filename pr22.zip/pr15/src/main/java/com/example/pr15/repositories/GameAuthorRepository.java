package com.example.pr15.repositories;

import com.example.pr15.models.GameAuthor;
import org.springframework.data.jpa.repository.JpaRepository;


public interface GameAuthorRepository extends JpaRepository<GameAuthor, Long> {

}