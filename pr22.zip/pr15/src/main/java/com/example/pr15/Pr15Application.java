package com.example.pr15;

import com.example.pr15.config.EmailConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import(EmailConfig.class)
public class Pr15Application {

	public static void main(String[] args) {
		SpringApplication.run(Pr15Application.class, args);
	}

}
