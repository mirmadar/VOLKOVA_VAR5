package com.example.pr15.services;

import com.example.pr15.logging.LogTime;
import com.example.pr15.models.GameAuthor;
import com.example.pr15.repositories.GameAuthorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class GameAuthorService {
    private final GameAuthorRepository gameAuthorRepository;

    private static final Logger logger = LoggerFactory.getLogger(GameAuthorService.class);

    public GameAuthorService(GameAuthorRepository gameAuthorRepository) {
        this.gameAuthorRepository = gameAuthorRepository;
    }

    @Transactional
    @LogTime
    public List<GameAuthor> getAllAuthors() {
        logger.info("Getting all game authors");
        return gameAuthorRepository.findAll();
    }

    @LogTime
    public GameAuthor getAuthorById(Long id) {
        logger.info("Getting game author by id: {}", id);
        return gameAuthorRepository.findById(id).orElse(null);
    }

    @LogTime
    public GameAuthor createAuthor(GameAuthor author) {
        logger.info("Creating game author: {}", author);
        return gameAuthorRepository.save(author);
    }

    @LogTime
    public void deleteAuthorById(Long id) {
        logger.info("Deleting game author by id: {}", id);
        gameAuthorRepository.deleteById(id);
    }
}