// Интерфейс, который должен реализовать каждый продукт "Продукт A"
interface ProductA {
    void use();
}

class ProductA1 implements ProductA {
    @Override
    public void use() {
        System.out.println("Это первая реализация продукта семейства A");
    }
}

class ProductA2 implements ProductA {
    @Override
    public void use() {
        System.out.println("Это вторая реализация продукта семейства A");
    }
}

// Интерфейс, который должен реализовать каждый "Продукт B"
interface ProductB {
    void run();
}

class ProductB1 implements ProductB {
    @Override
    public void run() {
        System.out.println("Это первая реализация продукта семейства B");
    }
}

class ProductB2 implements ProductB {
    @Override
    public void run() {
        System.out.println("Это вторая реализация продукта семейства B");
    }
}

// Абстрактная фабрика, которая создает продукты "Продукт A" и "Продукт B"
interface AbstractFactory {
    ProductA createProductA();
    ProductB createProductB();
}

// Реализация фабрики, которая создает "Продукт A1" и "Продукт B1"
class Factory1 implements AbstractFactory {
    @Override
    public ProductA createProductA() {
        return new ProductA1();
    }

    @Override
    public ProductB createProductB() {
        return new ProductB1();
    }
}

// Реализация фабрики, которая создает "Продукт A2" и "Продукт B2"
class Factory2 implements AbstractFactory {
    @Override
    public ProductA createProductA() {
        return new ProductA2();
    }

    @Override
    public ProductB createProductB() {
        return new ProductB2();
    }
}

// Клиентский код
public class myAbstractFactory {
    public static void main(String[] args) {
        AbstractFactory factory1 = new Factory1();
        ProductA productA1 = factory1.createProductA();
        ProductB productB1 = factory1.createProductB();

        productA1.use();
        productB1.run();

        AbstractFactory factory2 = new Factory2();
        ProductA productA2 = factory2.createProductA();
        ProductB productB2 = factory2.createProductB();

        productA2.use();
        productB2.run();
    }
}
