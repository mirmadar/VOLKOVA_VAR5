// Создаем интерфейс для нашего прототипа
interface Prototype {
    public Prototype clone();
}

// Создаем класс-прототип, который реализует интерфейс Prototype
class Phone implements Prototype {
    private String brand;
    private String model;
    private String color;

    public Phone(String brand, String model, String color) {
        this.brand = brand;
        this.model = model;
        this.color = color;
    }

    // Реализуем метод клонирования
    public Prototype clone() {
        return new Phone(brand, model, color);
    }

    // Создаем метод для вывода информации о телефоне
    public String toString() {
        return "телефон\n" +
                "бренд: " + brand  + " | " +
                "модель: " + model + " | " +
                "цвет: " + color;
    }

    public Phone setColor(String color) {
        this.color=color;
        return this;
    }
}

// Создаем класс-клиент, который будет использовать прототипы
public class myPrototype {
    public static void main(String[] args) {
        Phone prototype = new Phone("Iphone", "SE", "BLACK"); // Создаем объект-прототип

        Phone clone1 = (Phone) prototype.clone(); // Копируем объект-прототип
        System.out.println(clone1.toString()); // Выводим информацию о телефлне

        Phone clone2 = (Phone) prototype.clone();
        System.out.println(clone2.toString());

        clone2.setColor("WHITE"); // Изменяем цвет у одного из клонов

        System.out.println(clone1);
        System.out.println(clone2);
    }
}
