// Интерфейс, который должен реализовать каждый продукт
interface Product {
    void use();
}

class Product1 implements Product {
    @Override
    public void use() {
        System.out.println("Используем продукт 1");
    }
}

// Реализация продукта "Продукт 2"
class Product2 implements Product {
    @Override
    public void use() {
        System.out.println("Используем продукт 2");
    }
}

// Фабрика, которая создает продукты
interface ProductFactory {
    Product createProduct();
}

// Реализация фабрики, создающей "Продукт 1"
class Product1Factory implements ProductFactory {
    @Override
    public Product createProduct() {
        return new Product1();
    }
}

// Реализация фабрики, создающей "Продукт 2"
class Product2Factory implements ProductFactory {
    @Override
    public Product createProduct() {
        return new Product2();
    }
}

// Клиентский код
public class myFactoryMethod {
    public static void main(String[] args) {
        // Создаем фабрику для создания продукта 1
        ProductFactory factory1 = new Product1Factory();

        // Создаем продукт 1
        Product product1 = factory1.createProduct();

        // Используем продукт 1
        product1.use();

        // Создаем фабрику для создания продукта 2
        ProductFactory factory2 = new Product2Factory();

        // Создаем продукт 2
        Product product2 = factory2.createProduct();

        // Используем продукт 2
        product2.use();
    }
}
