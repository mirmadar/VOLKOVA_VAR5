class Pizza {
    private String dough;
    private String sauce;
    private String topping;

    public void setDough(String dough) {
        this.dough = dough;
    }

    public void setSauce(String sauce) {
        this.sauce = sauce;
    }

    public void setTopping(String topping) {
        this.topping = topping;
    }

    @Override
    public String toString() {
        return "Пицца\n" +
                "тесто: " + dough  + " | " +
                "соус: " + sauce + " | " +
                "начинка: " + topping;
    }

    public static class Builder {
        private String dough;
        private String sauce;
        private String topping;

        public Builder setDough(String dough) {
            this.dough = dough;
            return this;
        }

        public Builder setSauce(String sauce) {
            this.sauce = sauce;
            return this;
        }

        public Builder setTopping(String topping) {
            this.topping = topping;
            return this;
        }

        public Pizza build() {
            Pizza pizza = new Pizza();
            pizza.setDough(this.dough);
            pizza.setSauce(this.sauce);
            pizza.setTopping(this.topping);
            return pizza;
        }
    }
}

public class myBuilder{
    public static void main(String[] args){
        Pizza pizza = new Pizza.Builder()
                .setDough("толстенное")
                .setSauce("барбекю")
                .setTopping("сырочек")
                .build();
        System.out.println(pizza.toString());
    }
}