import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorServiceExample {
    public static void main(String[] args) {

        // Создаем ExecutorService с 5 потоками
        ExecutorService executor = Executors.newFixedThreadPool(5);

        // Запускаем 10 задач на выполнение
        for (int i = 0; i < 10; i++) {
            executor.submit(new Task(i));
        }

        // Останавливаем ExecutorService
        executor.shutdown();
    }
}

class Task implements Runnable {
    private int taskId;

    public Task(int taskId) {
        this.taskId = taskId;
    }

    public void run() {
        System.out.println("Задача " + taskId + " выполняется в потоке " + Thread.currentThread().getName());
    }
}