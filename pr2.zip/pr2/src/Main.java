import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Locale.setDefault(new Locale("ru", "RU"));
        Scanner scanner = new Scanner(System.in);
        List<Human> humans = new ArrayList<>();
        System.out.print("Введите информацию о человеке \n");
        while(true){
            System.out.print("Имя: ");
            String firstName = scanner.nextLine();
            if(firstName.isEmpty()) break;

            System.out.print("Фамилия: ");
            String lastName = scanner.nextLine();

            System.out.print("Возраст: ");
            int age = scanner.nextInt();

            Scanner scanner1 = new Scanner(System.in);
            System.out.print("Дата рождения (ГГГГ-ММ-ДД): ");
            String date = scanner1.nextLine();
            LocalDate birthDate = LocalDate.parse(date);

            System.out.print("Вес: ");
            int weight = scanner.nextInt();
            scanner.nextLine();

            Human human = new Human(age, firstName, lastName, birthDate, weight);
            humans.add(human);

            //System.out.print("Продолжить ввод данных для следующего человека? (да - 1, нет - 0): ");
            //int confirmation = scanner.nextInt();
        }
        /* humans.add(new Human(21, "Анастасия", "Волкова", LocalDate.of(2001, 6, 3), 53));
        humans.add(new Human(23, "Степан", "Бегларян", LocalDate.of(2000, 1, 20), 70));
        humans.add(new Human(46, "Райан", "Рейнольдс", LocalDate.of(1976, 10, 23), 79));
        humans.add(new Human(42, "Райан", "Гослинг", LocalDate.of(1980, 11, 12), 81));
        humans.add(new Human(21, "Игорь", "Пурин", LocalDate.of(2001, 7, 4), 77));*/

        // сортировка по возрасту в обратном порядке
        List<Human> sortedByAge = humans.stream()
                .sorted(Comparator.comparing(Human::getAge).reversed())
                .collect(Collectors.toList());

        // фильтрация по имени «начинается с А»
        List<Human> filteredByName = humans.stream()
                .filter(h -> h.getFirstName().startsWith("А"))
                //.sorted(Comparator.comparing(Human::getFirstName))
                .collect(Collectors.toList());

        // сортировка по дате рождения
        List<Human> sortedByBirthDate = humans.stream()
                .sorted(Comparator.comparing(Human::getBirthDate).reversed())
                .collect(Collectors.toList());

        // расчет среднего веса
        double averageWeight = humans.stream()
                .mapToInt(Human::getWeight)
                .average()
                .orElse(0.0);


        System.out.println("Сортировка по возрасту в обратном порядке: " + '\n' + sortedByAge);
        System.out.println("Фильтрация по имени «начинается с А»: " + '\n' + filteredByName);
        System.out.println("Сортировка по дате рождения: " + '\n' + sortedByBirthDate);
        System.out.println("Средний вес: " + averageWeight);
    }
}

class Human {
    public int age;
    public String firstName;
    public String lastName;
    public LocalDate birthDate;
    public int weight;

    public Human(int age, String firstName, String lastName, LocalDate birthDate, int weight) {
        this.age = age;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.weight = weight;
    }

    public int getAge() {
        return age;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public int getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return firstName + " " + lastName + ", " + birthDate + ", " + age + " y.o." + ", " + weight + " kg";
    }
}