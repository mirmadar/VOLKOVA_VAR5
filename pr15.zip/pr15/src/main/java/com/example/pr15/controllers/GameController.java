package com.example.pr15.controllers;

import com.example.pr15.models.Game;

import com.example.pr15.repositories.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.text.ParseException;
import java.util.List;

@Controller
@RequestMapping(value = "/games")
public class GameController {
    @Autowired
    private GameRepository gameRepository;

    @PostMapping
    public @ResponseBody Object createGame(@RequestParam String name,
                                           @RequestParam String creationDate){
//        Game game = new Game(name, new Date(creationDate));
        Game game = new Game(name, creationDate);
        return gameRepository.save(game);
    }

    @Transactional
    @DeleteMapping("/{name}")
    public @ResponseBody void deleteGame(@PathVariable String name) {
        gameRepository.deleteByName(name);
    }

    @GetMapping
    public @ResponseBody List<Game> getAllGames() {
        return gameRepository.findAll();
    }
}