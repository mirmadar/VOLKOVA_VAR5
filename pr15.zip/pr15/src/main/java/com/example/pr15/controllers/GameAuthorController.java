package com.example.pr15.controllers;

import com.example.pr15.models.GameAuthor;
import com.example.pr15.repositories.GameAuthorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@Controller
@RequestMapping(value = "/authors")
public class GameAuthorController {
    @Autowired
    private GameAuthorRepository gameAuthorRepository;

    @PostMapping
    public @ResponseBody Object createGameAuthor(@RequestParam String nickname,
                                                 @RequestParam String birthDate) {
//        GameAuthor gameAuthor = new GameAuthor(nickname, new Date(birthDate));
        GameAuthor gameAuthor = new GameAuthor(nickname,birthDate);
        return gameAuthorRepository.save(gameAuthor);
    }

    @Transactional
    @DeleteMapping("/{nickname}")
    public @ResponseBody void deleteGameAuthor(@PathVariable String nickname) {
        gameAuthorRepository.deleteByNickname(nickname);
    }

    @GetMapping
    public @ResponseBody List<GameAuthor> getAllGameAuthors() {
        return gameAuthorRepository.findAll();
    }
}