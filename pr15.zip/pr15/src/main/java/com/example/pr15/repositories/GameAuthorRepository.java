package com.example.pr15.repositories;

import com.example.pr15.models.GameAuthor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GameAuthorRepository extends JpaRepository<GameAuthor, String> {
    List<GameAuthor> deleteByNickname(String nickname);
}
