package com.example.pr15.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.sql.Date;

@Entity
@Table(name = "games")
public class Game {

    @Id
    @Column(name = "name")
    private String name;

    @Column(name = "creation_date")
    private String creationDate;

    public Game(String name, String creationDate){
        this.name = name;
        this.creationDate =creationDate;
    }

    public Game(){};


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }
}
