package com.example.pr15.controllers;

import com.example.pr15.models.Game;
import com.example.pr15.models.GameAuthor;
import com.example.pr15.repositories.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/games")
public class GameController {
    @Autowired
    private GameRepository gameRepository;

    @PostMapping
    public @ResponseBody Object createGame(@RequestBody Game game) {
        GameAuthor author = game.getAuthor();
        if (author.getGames() == null) {
            author.setGames(new ArrayList<>());
        }
        author.getGames().add(game); // связываем игру с автором
        return gameRepository.save(game);
    }

    @GetMapping
    public @ResponseBody List<Game> getAllGames() {
        return gameRepository.findAll();
    }

    @Transactional
    @DeleteMapping("/{id}")
    public @ResponseBody void deleteGame(@PathVariable Long id) {
        gameRepository.deleteById(id);
    }
}