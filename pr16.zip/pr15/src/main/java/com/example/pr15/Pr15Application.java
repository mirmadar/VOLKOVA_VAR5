package com.example.pr15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr15Application {

	public static void main(String[] args) {
		SpringApplication.run(Pr15Application.class, args);
	}

}
