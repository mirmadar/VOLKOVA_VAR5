package com.example.pr15.controllers;

import com.example.pr15.models.Game;
import com.example.pr15.services.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping(value = "/games")
public class GameController {
    @Autowired
    private final GameService gameService;

    public GameController(GameService gameService) {
        this.gameService = gameService;
    }

    @PostMapping
    public @ResponseBody Object createGame(@RequestBody Game game) {
        return gameService.createGame(game);
    }

    @GetMapping
    public @ResponseBody List<Game> getAllGames() {
        return gameService.getAllGames();
    }

    @Transactional
    @DeleteMapping("/{id}")
    public @ResponseBody void deleteGame(@PathVariable Long id) {
        gameService.deleteGameById(id);
    }

    @GetMapping("/filter")
    public @ResponseBody List<Game> filterGames(@RequestParam(required = false) String name,
                                                @RequestParam(required = false) Long authorId,
                                                @RequestParam(required = false) String creationDate) {
        return gameService.filterGames(name, authorId, creationDate);
    }
}
