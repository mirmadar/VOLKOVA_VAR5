package com.example.pr15.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "authors")
public class GameAuthor {
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "nickname")
    private String nickname;

    @Column(name = "birth_date")
    private String birthDate;

    @OneToMany(mappedBy = "author")
    List<Game> games;

    public GameAuthor(Long id, String nickname, String birthDate) {
        this.id=id;
        this.nickname = nickname;
        this.birthDate = birthDate;
    }

    public GameAuthor() {}

    public GameAuthor(String author) {
    }

    @Override
    public String toString() {
        return "{" +
                "id: " + id +
                ", nickname: '" + nickname + '\'' +
                ", birthDate: " + birthDate +
                '}';
    }

}
