package com.example.pr15.controllers;

import com.example.pr15.models.GameAuthor;
import com.example.pr15.services.GameAuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping(value = "/authors")
public class GameAuthorController {
    @Autowired
    private GameAuthorService gameAuthorService;

    @PostMapping
    public @ResponseBody Object createGameAuthor(@RequestParam Long id,
                                                 @RequestParam String nickname,
                                                 @RequestParam String birthDate) {
        GameAuthor gameAuthor = new GameAuthor(id,nickname,birthDate);
        return gameAuthorService.createAuthor(gameAuthor);
    }

    @Transactional
    @DeleteMapping("/{id}")
    public @ResponseBody void deleteGameAuthor(@PathVariable Long id) {
        gameAuthorService.deleteAuthorById(id);
    }

    @GetMapping
    public @ResponseBody List<GameAuthor> getAllGameAuthors() {
        return gameAuthorService.getAllAuthors();
    }

}