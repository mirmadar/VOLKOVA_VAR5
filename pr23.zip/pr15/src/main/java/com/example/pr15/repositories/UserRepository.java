package com.example.pr15.repositories;

import com.example.pr15.models.UserData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<UserData, Integer>
{
    @Query("select u from UserData u where u.username = :username")
    UserData findByUsername(@Param("username") String username);
}
