package com.example.pr11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.web.client.RestTemplate;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;



@SpringBootApplication
public class Pr11Application {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(Pr11Application.class, args);
//		RestTemplate restTemplate = new RestTemplate();
//		String status = restTemplate.getForObject("http://localhost:8080/actuator/health", String.class);
//		System.out.println("Status: " + status);
	}
}

//gradle bootJar
//java -jar build/libs/pr11-0.0.1-SNAPSHOT.jar
