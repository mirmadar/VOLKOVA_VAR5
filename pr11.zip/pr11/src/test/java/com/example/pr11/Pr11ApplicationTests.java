package com.example.pr11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
