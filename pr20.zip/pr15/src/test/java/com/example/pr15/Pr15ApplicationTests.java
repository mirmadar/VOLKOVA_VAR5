package com.example.pr15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
