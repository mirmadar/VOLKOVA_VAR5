package com.example.pr13;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class Test implements CommandLineRunner{
    @Autowired
    private ApplicationContext context;

    @Override
    public void run(String... args) throws Exception {
        printStudentInfo();
    }
    public void printStudentInfo() {
        Environment environment = context.getEnvironment();
        String name = environment.getProperty("student.name");
        String lastName = environment.getProperty("student.last_name");
        String group = environment.getProperty("student.group");
        System.out.printf("Student info: name = %s, last_name = %s, group = %s", name, lastName, group);
    }
}