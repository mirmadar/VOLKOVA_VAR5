package com.example.pr15.services;

import com.example.pr15.models.Game;
import com.example.pr15.models.GameAuthor;
import com.example.pr15.repositories.GameRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class GameService {

    private final GameRepository gameRepository;
    private static final Logger logger = LoggerFactory.getLogger(GameService.class);

    public GameService(GameRepository gameRepository) {
        this.gameRepository = gameRepository;
    }

    public Game createGame(Game game) {
        logger.debug("Creating game: {}", game);
        GameAuthor author = game.getAuthor();
        if (author.getGames() == null) {
            author.setGames(new ArrayList<>());
        }
        author.getGames().add(game); // связываем игру с автором
        Game savedGame = gameRepository.save(game);
        logger.debug("Game created: {}", savedGame);
        return savedGame;
    }

    public List<Game> getAllGames() {
        logger.debug("Getting all games");
        List<Game> games = gameRepository.findAll();
        logger.debug("Found {} games", games.size());
        return games;
    }

    public void deleteGameById(Long id) {
        logger.debug("Deleting game with id: {}", id);
        gameRepository.deleteById(id);
        logger.debug("Game with id {} deleted", id);
    }


    @PersistenceContext
    private EntityManager entityManager;

    public List<Game> filterGames(String name, Long authorId, String creationDate) {
        logger.debug("Filtering games with name: {}, authorId: {}, creationDate: {}", name, authorId, creationDate);
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Game> criteriaQuery = builder.createQuery(Game.class);
        Root<Game> root = criteriaQuery.from(Game.class);
        // создаем пустой список предикатов
        List<Predicate> predicates = new ArrayList<>();
        // добавляем предикаты для каждого переданного параметра
        if (name != null) {
            predicates.add(builder.like(root.get("name"), "%" + name + "%"));
        }
        if (authorId != null) {
            Join<Game, GameAuthor> authorJoin = root.join("author");
            predicates.add(builder.equal(authorJoin.get("id"), authorId));
        }
        if (creationDate != null) {
            predicates.add(builder.equal(root.get("creationDate"), creationDate));
        }
        // добавляем все предикаты в запрос
        criteriaQuery.where(predicates.toArray(new Predicate[predicates.size()]));

        TypedQuery<Game> query = entityManager.createQuery(criteriaQuery);
        List<Game> games = query.getResultList();
        logger.debug("Found {} games", games.size());
        return games;
    }
}