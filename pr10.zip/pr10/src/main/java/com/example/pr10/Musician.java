package com.example.pr10;

//import org.springframework.context.annotation.Bean;
//
//@Bean
public interface Musician {
    void doCoding();
}
