package com.example.pr10;

//import org.springframework.context.annotation.Bean;
//
//@Bean
public class Trombonist implements Musician {
    @Override
    public void doCoding(){
        System.out.println("................................");
        System.out.println("I`m Trombonist and I`m coding");
        System.out.println("................................");
    }
}
