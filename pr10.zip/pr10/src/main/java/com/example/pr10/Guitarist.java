package com.example.pr10;

//import org.springframework.context.annotation.Bean;
//
//@Bean
public class Guitarist implements Musician {
    @Override
    public void doCoding(){
        System.out.println("...............................");
        System.out.println("I`m a Guitarist and I`m coding");
        System.out.println("...............................");
    }

}
