package com.example.pr12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileHasherApplicationTests {

	@Test
	void contextLoads() {
	}

}
