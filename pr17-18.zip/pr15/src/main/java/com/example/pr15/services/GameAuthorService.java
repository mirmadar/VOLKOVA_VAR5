package com.example.pr15.services;

import com.example.pr15.models.GameAuthor;
import com.example.pr15.repositories.GameAuthorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GameAuthorService {
    private final GameAuthorRepository gameAuthorRepository;

    public GameAuthorService(GameAuthorRepository gameAuthorRepository) {
        this.gameAuthorRepository = gameAuthorRepository;
    }

    public List<GameAuthor> getAllAuthors() {
        return gameAuthorRepository.findAll();
    }

    public GameAuthor getAuthorById(Long id) {
        return gameAuthorRepository.findById(id).orElse(null);
    }

    public GameAuthor createAuthor(GameAuthor author) {
        return gameAuthorRepository.save(author);
    }

    public void deleteAuthorById(Long id) {
        gameAuthorRepository.deleteById(id);
    }
}