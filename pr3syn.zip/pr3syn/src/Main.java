import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        Queue queue = new Queue();
        Thread t1 = new Thread(new AddToQueue(queue));
        Thread t2 = new Thread(new ExtractFromGueue(queue));

        t1.start();
        t2.start();
    }
}

class Queue {
    private LinkedList<Integer> numbers = new LinkedList<>();

    public synchronized void addNumber(Integer number) {
        numbers.addLast(number);
        notifyAll();
    }

    public synchronized Integer getNextNumber() throws InterruptedException {
        while (numbers.isEmpty()) {
            wait();
        }
        return numbers.removeFirst();
    }

    public synchronized boolean isEmpty() {
        return numbers.isEmpty();
    }
}

class AddToQueue implements Runnable {
    private Queue queue;

    public AddToQueue(Queue queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
            for (int i = 1; i <= 10; i++) {
                queue.addNumber(i);
                Thread.sleep(500);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class ExtractFromGueue implements Runnable {
    private Queue queue;

    public ExtractFromGueue(Queue queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        try {
            while (!queue.isEmpty()) {
                Integer number = queue.getNextNumber();
                System.out.println("мы вытащили " + "'" + number + "'" + " из очереди");
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
